from gcs_to_mongo import get_data, gcs_to_mongodb_collection, calculate_summary_statistics, embed_descriptions
from airflow.operators.python import PythonOperator
from airflow import DAG
from datetime import datetime
import os
import sys

# Define the DAG for the search engine pipeline
with DAG(
    dag_id="job-recommender",
    start_date=datetime(2024, 3, 5),
    schedule_interval="@daily",
) as dag:

    # Set environment variable for no_proxy
    os.environ["no_proxy"] = "*"

    # Define the PythonOperator for fetching jobs data
    get_jobs_op = PythonOperator(
        task_id="get_jobs_data", python_callable=get_data
    )

    # Define the PythonOperator for transferring data from GCS to MongoDB
    gcs_to_mongo_op = PythonOperator(
        task_id="gcs_to_mongo", python_callable=gcs_to_mongodb_collection
    )

    # Define the PythonOperator for calculating summary statistics
    summary_statistics_op = PythonOperator(
        task_id="summary_statistics", python_callable=calculate_summary_statistics
    )

    # Define the PythonOperator for converting job descriptions to embeddings
    convert_to_embeddings_op = PythonOperator(
        task_id="convert_to_embeddings", python_callable=embed_descriptions
    )

    # Set the task dependencies
    get_jobs_op >> gcs_to_mongo_op >> convert_to_embeddings_op >> summary_statistics_op

