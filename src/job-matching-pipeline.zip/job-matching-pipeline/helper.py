import os
import json
import re
import time
import pandas as pd
from google.cloud import storage
from google.cloud import vision
import warnings
import pymongo
import certifi
from langchain_google_vertexai import VertexAI
from langchain.embeddings import HuggingFaceInstructEmbeddings
from langchain_community.vectorstores import MongoDBAtlasVectorSearch
from user_definition import *
from google.oauth2 import service_account
from google.cloud import aiplatform

from io import BytesIO

# Set the Google Application Credentials environment variable
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = os.environ['GOOGLE_API_KEY']

def generate_prompt(resume_text, job_description):
    """
    Generates a prompt for comparing a resume to a job description.

    Args:
        resume_text (str): Text content of the resume.
        job_description (str): Text content of the job description.

    Returns:
        str: Formatted prompt for comparison.
    """
    prompt = f"""
                You are tasked with developing a tool to assist job seekers in matching their resumes to job descriptions effectively. 
                Your tool will compare the content of a resume to the job description of a specific job and provide concise insights into 
                the alignment between the two. Your task is to generate two concise bullet points summarizing the matching keywords, 
                skillsets or any other information found in both the resume and the job description. These bullet points should highlight 
                why the resume and the job listing are a good match based on the shared keywords and skillsets. Given below is the resume text 
                and the job description.

                Resume text:{resume_text}

                Job description:{job_description}

                """
    return prompt

# Function to upload file to Google Cloud Storage
def upload_to_gcs(file_contents, bucket_name, destination_blob_name):
    """
    Uploads file contents to Google Cloud Storage.

    Args:
        file_contents (str): Contents of the file to be uploaded.
        bucket_name (str): Name of the Google Cloud Storage bucket.
        destination_blob_name (str): Name of the destination blob.

    Returns:
        str: Google Cloud Storage URL of the uploaded file.
    """
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)
    blob.upload_from_string(file_contents, content_type='application/pdf')
    return f'gs://{bucket_name}/{destination_blob_name}'

def get_matching_points(resume_text, job_descriptions):
    """
    Retrieves matching points between a resume and multiple job descriptions.

    Args:
        resume_text (str): Text content of the resume.
        job_descriptions (list): List of job descriptions.

    Returns:
        list: Matching points between the resume and job descriptions.
    """
    matching_points = []
    model = VertexAI(model_name="gemini-pro", project=GCP_PROJECT_NAME)
    for job_description in job_descriptions:
        prompt = generate_prompt(resume_text, job_description)
        points = model.invoke(prompt)
        matching_points.append(points)
        time.sleep(2)
    return matching_points

def parse_resume(resume, user_sample=True):
    """
    Parses resume text from either a user sample file or an uploaded resume.

    Args:
        resume: Uploaded resume file or user sample flag.

    Returns:
        str: Extracted text from the resume.
    """
    if user_sample:
        with open('resume/Param_Mehta_Resume.txt', 'r') as file:
            file_contents = file.read()
        return file_contents

    file_contents = resume.read()
    file_name = resume.name

    # Specify your Google Cloud Storage bucket name and destination blob name
    gs_output_path = f'gs://{GS_BUCKET_NAME}/parsed_resume_txt/'
    destination_blob_name = f'uploaded_resume_pdf/{file_name}'

    gcs_url = upload_to_gcs(
        file_contents, GS_BUCKET_NAME, destination_blob_name)
    docs = async_detect_document(gcs_url, gs_output_path)

    return docs[0]

def find_jobs(title, resume_text):
    """
    Finds jobs based on a given job title and resume text.

    Args:
        title (str): Job title.
        resume_text (str): Text content of the resume.

    Returns:
        pd.DataFrame: Dataframe containing job details and matching points.
    """
    warnings.filterwarnings('ignore', category=UserWarning, message='TypedStorage is deprecated')
    embeddings_function = HuggingFaceInstructEmbeddings(
        model_name="hkunlp/instructor-base", model_kwargs={"device": 'cpu'})

    print(title)
    vector_search = MongoDBAtlasVectorSearch.from_connection_string(
        ATLAS_CONNECTION_STRING,
        f"{DB_NAME}.{JOBS_COLLECTION_NAME}",
        embeddings_function,
        index_name=VECTOR_INDEX_NAME)

    # Execute the similarity search with the given query
    results = vector_search.similarity_search_with_score(
        query=resume_text,
        k=3,
        pre_filter={"searchTitle": {"$eq": title}},
    )

    results_df = get_results_df(results, resume_text)

    return results
